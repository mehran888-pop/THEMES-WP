<?php
/**
 * Assets.
 *
 * @package Orvio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_enqueue_scripts', 'orvio_enqueue', 20 );
function orvio_enqueue() {
	$css = ORVIO_DIR . '/assets/css/main.css';
	$js  = ORVIO_DIR . '/assets/js/theme.js';
	$deps = array();
	$js_deps = array();
	if ( wp_style_is( 'woocommerce-general', 'registered' ) ) {
		$deps[] = 'woocommerce-general';
	}
	if ( wp_script_is( 'wc-add-to-cart', 'registered' ) ) {
		$js_deps = array( 'jquery', 'wc-add-to-cart' );
	}
	wp_enqueue_style( 'orvio', ORVIO_URI . '/assets/css/main.css', $deps, file_exists( $css ) ? filemtime( $css ) : ORVIO_VERSION );
	wp_enqueue_style( 'orvio-style', get_stylesheet_uri(), array( 'orvio' ), ORVIO_VERSION );
	wp_enqueue_script( 'orvio', ORVIO_URI . '/assets/js/theme.js', $js_deps, file_exists( $js ) ? filemtime( $js ) : ORVIO_VERSION, true );
	if ( orvio_opt( 'bale_support_enabled', 0 ) && orvio_opt( 'bale_support_bot_token', '' ) ) {
		$support_css = ORVIO_DIR . '/assets/css/support.css';
		$support_js  = ORVIO_DIR . '/assets/js/support.js';
		wp_enqueue_style( 'orvio-support', ORVIO_URI . '/assets/css/support.css', array( 'orvio' ), file_exists( $support_css ) ? filemtime( $support_css ) : ORVIO_VERSION );
		wp_enqueue_script( 'orvio-support', ORVIO_URI . '/assets/js/support.js', array(), file_exists( $support_js ) ? filemtime( $support_js ) : ORVIO_VERSION, true );
		wp_localize_script( 'orvio-support', 'OrvioSupport', array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'orvio_support' ),
			'i18n'  => array( 'error' => orvio_t( 'Could not send the message. Please try again.', 'ارسال پیام انجام نشد. دوباره تلاش کنید.' ) ),
		) );
	}
	wp_localize_script( 'orvio', 'OrvioData', array(
		'ajax'     => admin_url( 'admin-ajax.php' ),
		'nonce'    => wp_create_nonce( 'orvio' ),
		'cart'     => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
		'cartType' => orvio_opt( 'cart_type', 'drawer' ),
		'atcBehavior' => orvio_opt( 'atc_behavior', 'auto' ),
		'checkout' => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
		'i18n'     => array(
			'added'    => orvio_t( 'Added to bag', 'به سبد اضافه شد' ),
			'empty'    => orvio_t( 'Your bag is empty.', 'سبد شما خالی است.' ),
			'sent'     => orvio_t( 'Message received.', 'پیام شما ثبت شد.' ),
			'required' => orvio_t( 'Please fill this field.', 'این فیلد را پر کنید.' ),
		),
	) );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}

add_action( 'admin_enqueue_scripts', 'orvio_admin_assets' );
function orvio_admin_assets( $hook ) {
	if ( false === strpos( (string) $hook, 'orvio' ) ) {
		return;
	}
	wp_enqueue_style( 'orvio-admin', ORVIO_URI . '/assets/css/admin.css', array(), ORVIO_VERSION );
	wp_enqueue_script( 'orvio-admin', ORVIO_URI . '/assets/js/admin.js', array(), ORVIO_VERSION, true );
}

add_action( 'wp_head', 'orvio_button_overrides', 100 );
function orvio_button_overrides() {
	$style = orvio_opt( 'atc_style', 'pill' );
	$radius = 'pill' === $style ? '999px' : ( 'soft' === $style ? '14px' : '12px' );
	$bg     = 'outline' === $style ? 'transparent' : ( 'soft' === $style ? 'var(--accent-soft)' : 'var(--button-bg)' );
	$color  = 'outline' === $style || 'soft' === $style ? 'var(--ink)' : 'var(--button-text)';
	$border = 'outline' === $style ? '1.5px solid var(--ink)' : '0';
	$width  = 'block' === $style ? '100%' : 'auto';
	$flex   = 'block' === $style ? '1 1 100%' : '1 1 auto';
	$hover  = 'outline' === $style ? 'background:var(--button-hover)!important;color:var(--button-hover-text)!important' : ( 'soft' === $style ? 'background:var(--button-hover)!important;color:var(--button-hover-text)!important' : 'background:var(--button-hover)!important;color:var(--button-hover-text)!important' );
	$product_bg    = sanitize_hex_color( orvio_opt( 'product_button_bg', '#1C1916' ) ) ?: '#1C1916';
	$product_hover = sanitize_hex_color( orvio_opt( 'product_button_hover', '#A34B2B' ) ) ?: '#A34B2B';
	$product_color = sanitize_hex_color( orvio_opt( 'product_button_text', '#FFFFFF' ) ) ?: '#FFFFFF';
	$product_size  = max( 11, min( 20, absint( orvio_opt( 'product_button_size', 14 ) ) ) );
	$product_radius = max( 0, min( 44, absint( orvio_opt( 'product_radius', 24 ) ) ) );
	echo '<style id="orvio-atc">.woocommerce div.product form.cart,.woocommerce div.product form.cart .woocommerce-variation-add-to-cart,.woocommerce div.product form.cart .orvio-buy{display:flex;flex-wrap:wrap;align-items:center;gap:10px}.woocommerce div.product form.cart .variations,.woocommerce div.product form.cart table.variations,.woocommerce div.product form.cart .single_variation_wrap{flex:1 1 100%;width:100%}.woocommerce div.product form.cart .quantity,.woocommerce div.product form.cart .orvio-qty{float:none!important;margin:0!important}.woocommerce div.product .single_add_to_cart_button,.woocommerce div.product form.cart button.button.alt,.woocommerce div.product form.cart .orvio-btn--primary{float:none!important;flex:' . $flex . '!important;display:inline-flex!important;align-items:center;justify-content:center;box-sizing:border-box;width:' . $width . '!important;max-width:100%;min-width:0;min-height:48px!important;height:auto!important;padding:12px 18px!important;border:' . $border . '!important;border-radius:' . $radius . '!important;background:' . $bg . '!important;color:' . $color . '!important;font-weight:700!important;font-size:14px!important;line-height:1.35!important;white-space:normal!important;text-align:center;box-shadow:none!important;text-shadow:none!important;overflow:visible}.woocommerce div.product .single_add_to_cart_button:hover{' . $hover . '}.woocommerce div.product .single_add_to_cart_button.disabled,.woocommerce div.product .single_add_to_cart_button:disabled{opacity:.45!important}</style><style id="orvio-product-atc">body.single-product .orvio-product--premium .orvio-product__buybox .single_add_to_cart_button,body.single-product .orvio-product--premium .orvio-product__buybox button.button.alt,body.single-product .orvio-product--premium .orvio-product__buybox .orvio-btn--primary,body.single-product .orvio-sticky-atc .orvio-btn--primary{background:' . $product_bg . '!important;color:' . $product_color . '!important;border-color:' . $product_bg . '!important;border-radius:' . $product_radius . 'px!important;font-size:' . $product_size . 'px!important;}body.single-product .orvio-product--premium .orvio-product__buybox .single_add_to_cart_button:hover,body.single-product .orvio-product--premium .orvio-product__buybox button.button.alt:hover,body.single-product .orvio-sticky-atc .orvio-btn--primary:hover{background:' . $product_hover . '!important;color:' . $product_color . '!important;}</style>';
}

add_filter( 'woocommerce_enqueue_styles', 'orvio_dequeue_wc_styles' );
function orvio_dequeue_wc_styles( $styles ) {
	unset( $styles['woocommerce-layout'], $styles['woocommerce-smallscreen'] );
	return $styles;
}
